create database db_oficial;
use db_oficial;

create table trajetotaxi ( 
   id int unsigned not null auto_increment, 
   taxi_id int,
   when_ocurrs date, 
   longitude varchar(15), 
   latitude varchar(15), 
   primary key(id));

create table trajetotaxi_index ( 
   id int unsigned not null auto_increment, 
   taxi_id int,
   when_ocurrs date, 
   longitude varchar(15), 
   latitude varchar(15), 
   primary key(id)); 

alter table trajetotaxi_index add index (longitude, latitude);

select * from trajetotaxi_index;