package data.dao;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import domain.TrajetoTaxi;
import data.util.ConexaoA;

public class TrajetoTaxiDAO {
    
    private static TrajetoTaxi makeModel(ConexaoA conexao) throws SQLException {
        return new TrajetoTaxi(conexao.getInt("id"), conexao.getInt("taxi_id"), conexao.getDate("when_ocurrs"), conexao.getString("latitude"), conexao.getString("longitude"));
    }
    
    public static void inserirTrajetoTaxi(TrajetoTaxi t, ConexaoA conexao) throws SQLException {
        conexao.setQuery("insert into trajetotaxi (when_ocurrs, taxi_id, longitude, latitude) values (?, ?, ?, ?) ");
        conexao.setDate(1, t.getWhen());
        conexao.setInt(2, t.getIdveicle());
        conexao.setString(3, t.getLongitude());
        conexao.setString(4, t.getLatitude());
        conexao.executeUpdate();
    }
    
    public static void inserirTrajetoTaxiIndex(TrajetoTaxi t, ConexaoA conexao) throws SQLException {
    	conexao.setQuery("insert into trajetotaxi_index (when_ocurrs, taxi_id, longitude, latitude) values (?, ?, ?, ?) ");
    	conexao.setDate(1, t.getWhen());
    	conexao.setInt(2, t.getIdveicle());
    	conexao.setString(3, t.getLongitude());
    	conexao.setString(4, t.getLatitude());
        conexao.executeUpdate();
    }
    
    public static ArrayList<TrajetoTaxi> listarTrajetoTaxi(ConexaoA conexao, String longitude, String latitude) throws SQLException, ParseException {
        ArrayList<TrajetoTaxi> reg = new ArrayList<>();
        String sql = "select id, taxi_id, when_ocurrs, taxi_id, longitude, latitude "
            + "from trajetotaxi "
            + "where longitude = ? "
            + "  and latitude = ? ";
        conexao.setQuery(sql);
        conexao.setString(1, longitude);
        conexao.setString(2, latitude);
        conexao.executeQuery();
        while(conexao.next()) {
            reg.add(makeModel(conexao));
        }
        System.out.println("Registros: " + reg.stream().count());
        return reg;
    } 
    
    public static ArrayList<TrajetoTaxi> listarTrajetoTaxiIndex(ConexaoA conexao, String longitude, String latitude) throws SQLException, ParseException {
        ArrayList<TrajetoTaxi> reg = new ArrayList<>();
        String sql = "select id, taxi_id, when_ocurrs, taxi_id, longitude, latitude "
            + "from trajetotaxi_index "
            + "where longitude = ? "
            + "  and latitude = ? ";
        conexao.setQuery(sql);
        conexao.setString(1, longitude);
        conexao.setString(2, latitude);
        conexao.executeQuery();
        while(conexao.next()) {
            reg.add(makeModel(conexao));
        }
        System.out.println("Registros: " + reg.stream().count());
        return reg;
    } 
    
    public static void limparTabelas(ConexaoA conexao) throws SQLException {
    	conexao.setQuery("truncate table trajetotaxi");
    	conexao.executeUpdate();
    	conexao.setQuery("truncate table trajetotaxi_index");
    	conexao.executeUpdate();
    	conexao.commit();
    	System.out.println("Finalizado limpeza das tabelas");
    }
    
}
