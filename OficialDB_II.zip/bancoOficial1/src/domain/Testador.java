package domain;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;
import data.dao.TrajetoTaxiDAO;
import data.util.ConexaoA;

public class Testador {
    public static void main(String[] args) throws ClassNotFoundException, SQLException, ParseException {
        ConexaoA conexao = new ConexaoA();
        final String log = "116.48361";
        final String lat = "39.94491";
        Date iniciodaPesquisa = new Date();
        Date fimdaPesquisa = new Date();
        
        System.out.println("Deletando registros antigos");
        TrajetoTaxiDAO.limparTabelas(conexao);
        System.out.println("");
        
        //inserindo 
        System.out.println("Inserindo 100.000 registros");
        AlimentarBanco.carregarRegistros(conexao, 100000); 
        //Busca dos registros sem index
        System.out.println(String.format("Buscar registro sem index: logitude: %s - latitude: %s", log, lat));
        iniciodaPesquisa = new Date();
        TrajetoTaxiDAO.listarTrajetoTaxi(conexao, log, lat);
        fimdaPesquisa = new Date();
        System.out.println(String.format("Tempo %s ms", fimdaPesquisa.getTime() - iniciodaPesquisa.getTime()));
        System.out.println("");
        System.out.println(String.format("Buscar registro com index: logitude %s - latitude: %s", log, lat));
        //Busca dos registros com index
        iniciodaPesquisa = new Date();
        TrajetoTaxiDAO.listarTrajetoTaxiIndex(conexao, log, lat);
        fimdaPesquisa = new Date();
        System.out.println(String.format("Tempo: %s ms", fimdaPesquisa.getTime() - iniciodaPesquisa.getTime()));
               
        conexao.commit();
    }
}
