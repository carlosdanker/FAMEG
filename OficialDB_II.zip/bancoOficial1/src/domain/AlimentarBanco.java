package domain;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import data.dao.TrajetoTaxiDAO;
import domain.TrajetoTaxi;
import data.util.ConexaoA;

public class AlimentarBanco {
    private static final File RESOURCES = new File("resources");
    
    public static void carregarRegistros(ConexaoA conexao, int numeroLinhas) throws ClassNotFoundException, SQLException {
        ArrayList<File> scriptFiles = new ArrayList<>();
        estruturaArquivos(RESOURCES.listFiles(), scriptFiles);  
        final ArrayList<TrajetoTaxi> trajetoTaxi = new ArrayList<>();
        scriptFiles.forEach(o -> {
            
            try {
                trajetoTaxi.addAll(listarTrajetoTaxi(o));
            } catch (IOException | ParseException ex) {
                Logger.getLogger(AlimentarBanco.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }); 
        
        System.out.println("Inserindo dados nas tabelas");
        
        trajetoTaxi.stream().limit(numeroLinhas).forEach(t -> {
            try {
                TrajetoTaxiDAO.inserirTrajetoTaxi(t, conexao);
                TrajetoTaxiDAO.inserirTrajetoTaxiIndex(t, conexao);
            } catch (SQLException ex) {
                Logger.getLogger(AlimentarBanco.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        System.out.println("Finalizado insercao dos registros");
        System.out.println("");
    }
    
    private static ArrayList<TrajetoTaxi> listarTrajetoTaxi(File f) throws FileNotFoundException, IOException, ParseException {
        BufferedReader br = new BufferedReader(new FileReader(f));
        ArrayList<TrajetoTaxi> result = new ArrayList<>();
        String line;
        while( ( line = br.readLine()) != null) {
            result.add(TrajetoTaxi.parser(line));
        }
        return result;
    }
    
    private static void estruturaArquivos(File[] files, ArrayList<File> scriptFiles) {
        for(File file : files) {
            if(file.isDirectory())
                estruturaArquivos(file.listFiles(), scriptFiles);
            else 
                scriptFiles.add(file);
        }
    }
    
}
